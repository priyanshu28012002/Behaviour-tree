// #include <behaviortree_ros2/bt_action_node.hpp>
// #include <iostream>
// #include <rclcpp/executors.hpp>
// #include <rclcpp/rclcpp.hpp>

// #include "behaviortree_cpp_v3/basic_types.h"
// #include "behaviortree_cpp_v3/tree_node.h"
// #include "std_msgs/msg/string.hpp"
// #include <atomic>
// #include <chrono>
// #include <cmath>
// #include <functional>
// #include <memory>
// #include <string>
// #include <thread>

// #include "geometry_msgs/msg/twist.hpp"
// #include "nav_msgs/msg/odometry.hpp"
// #include "sensor_msgs/msg/laser_scan.hpp"
// #include <geometry_msgs/msg/pose_stamped.hpp>
// // #include <tf2_geometry_msgs/tf2_geometry_msgs/tf2_geometry_msgs.h>

// #include "behaviortree_cpp_v3/loggers/bt_file_logger.h"
// #include <math.h>

// using namespace std::chrono_literals;
// using std::chrono::milliseconds;
// using std::placeholders::_1;
// std::atomic_bool switchActive{true};

// using namespace BT;

// float data1;
// float data2;
// float robotAngle;
// float position_x;
// float position_y;

// //-------------------------------------------------------------------------------------
// //------------------------------LASER--------------------------------------------------
// //-------------------------------------------------------------------------------------

// class ReadingLaser : public BT::SyncActionNode, public rclcpp::Node {

// private:
//   rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr subscription_;

//   void topic_callback(const sensor_msgs::msg::LaserScan::SharedPtr _msg) {

//     RCLCPP_INFO(this->get_logger(), "We get suscription");


//     data2 = _msg->ranges[100];
//     data1 = _msg->ranges[0];
//   }

// public:
//   ReadingLaser(const std::string &name, const BT::NodeConfiguration &config)
//       : BT::SyncActionNode(name, config), Node("scanner_node") {
//     RCLCPP_INFO(this->get_logger(), "This is a CONSTRUCTOR");
//     auto sensor_qos = rclcpp::QoS(rclcpp::SensorDataQoS());

//     subscription_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
//         "/scan", sensor_qos,
//         [&](const sensor_msgs::msg::LaserScan::SharedPtr msg) {
//           topic_callback(msg);
//         });
//   }

//   BT::NodeStatus tick() override {

//     auto res = getInput<float>("input");
//     if (!res) {
//       throw RuntimeError("error reading port [input]:", res.error());
//     }
//     float angleConstraint = res.value();

//     RCLCPP_INFO(this->get_logger(), "This is a tick()-------");
//     RCLCPP_INFO(this->get_logger(), "NODE : LASER DATA ===>: '%f' '%f'", data1,
//                 data2);
//     // 200 readings, from right to left, from -57 to 57 degress
//     // calculate new velocity cmd
//     float min = 10;
//     float current;
//     for (int i = 0; i < 200; i++) {
//       current = data1;
//       if (current < min) {
//         min = current;
//       }
//     }

//     std::this_thread::sleep_for(std::chrono::milliseconds(10));

//     return (data1 > 2 && robotAngle > angleConstraint) ? NodeStatus::SUCCESS
//                                                        : NodeStatus::FAILURE;
//   }

//   static PortsList providedPorts() {

//     const char *description = "Simply print the target on console...";
//     return {InputPort<float>("input", description)};
//   }
// };

// //-------------------------------------------------------------------------------------
// //--------------------------MOVE_ROBOT-------------------------------------------------
// //-------------------------------------------------------------------------------------

// class MoveRobot : public BT::SyncActionNode, public rclcpp::Node {

// public:
//   MoveRobot(const std::string &name, const BT::NodeConfiguration &config)
//       : BT::SyncActionNode(name, config), Node("rotating_node") {

//     auto sensor_qos = rclcpp::QoS(rclcpp::SensorDataQoS());

//     subscription_ = this->create_subscription<nav_msgs::msg::Odometry>(
//         "/odom", sensor_qos, [&](const nav_msgs::msg::Odometry::SharedPtr msg) {
//           odometry_callback(msg);
//         });
//   }

//   NodeStatus tick() override {

//     auto res = getInput<float>("input");
//     if (!res) {
//       throw RuntimeError("error reading port [input]:", res.error());
//     }
//     float x_or_y = res.value();

//     publisher_ =
//         this->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel", 10);

//     auto message = geometry_msgs::msg::Twist();

//     RCLCPP_INFO(this->get_logger(), "robot position: '%f' '%f'", position_x,
//                 position_y);

//     if (x_or_y == 1) {
//       message.linear.x = 0.5;
//     }
//     if (x_or_y == 2) {
//       message.linear.y = 0.5;
//     }

//     const geometry_msgs::msg::PoseStamped::SharedPtr msg;

//     publisher_->publish(message);

//     std::this_thread::sleep_for(std::chrono::milliseconds(100));

//     return position_x > 3.0 || position_y > 3.0 ? NodeStatus::SUCCESS
//                                                 : NodeStatus::FAILURE;
//   }

//   static PortsList providedPorts() {

//     const char *description = "Simply print the target on console...";
//     return {InputPort<float>("input", description)};
//   }

// private:
//   void odometry_callback(const nav_msgs::msg::Odometry::SharedPtr _msg) {

//     position_x = _msg->pose.pose.position.x;
//     position_y = _msg->pose.pose.position.y;
//   }

//   void timer_callback() {
//     RCLCPP_INFO(this->get_logger(), "yaw: '%f'", robotAngle);
//     auto message = geometry_msgs::msg::Twist();

//     const geometry_msgs::msg::PoseStamped::SharedPtr msg;

//     publisher_->publish(message);
//   }

//   rclcpp::TimerBase::SharedPtr timer_;
//   rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr subscription_;
//   rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr publisher_;
// };

// //-------------------------------------------------------------------------------------
// //---------------------ROTATING_ROBOT--------------------------------------------------
// //-------------------------------------------------------------------------------------

// // class Rotating : public BT::SyncActionNode, public rclcpp::Node {

// // public:
// //   Rotating(const std::string &name, const BT::NodeConfiguration &config)
// //       : BT::SyncActionNode(name, config), Node("rotating_node") {

// //     auto sensor_qos = rclcpp::QoS(rclcpp::SensorDataQoS());

// //     subscription_ = this->create_subscription<nav_msgs::msg::Odometry>(
// //         "/odom", sensor_qos, [&](const nav_msgs::msg::Odometry::SharedPtr msg) {
// //           odometry_callback(msg);
// //         });
// //   }

// //   NodeStatus tick() override {
// //     auto res = getInput<float>("input");
// //     if (!res) {
// //       throw RuntimeError("error reading port [input]:", res.error());
// //     }
// //     float angle = res.value();

// //     publisher_ =
// //         this->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel", 10);

// //     RCLCPP_INFO(this->get_logger(), "yaw: '%f'", robotAngle);
// //     RCLCPP_INFO(this->get_logger(), "ROTATE NODE: LASER ===>: '%f' '%f'", data1,
// //                 data2);
// //     auto message = geometry_msgs::msg::Twist();

// //     message.angular.z = 0.4;

// //     const geometry_msgs::msg::PoseStamped::SharedPtr msg;

// //     publisher_->publish(message);

// //     std::this_thread::sleep_for(std::chrono::milliseconds(100));

// //     return NodeStatus::SUCCESS;
// //   }

// //   static PortsList providedPorts() {

// //     const char *description = "Simply print the target on console...";
// //     return {InputPort<float>("input", description)};
// //   }

// // private:
// //   void odometry_callback(const nav_msgs::msg::Odometry::SharedPtr _msg) {

// //     tf2::Quaternion quat_tf;
// //     geometry_msgs::msg::Quaternion quat_msg = _msg->pose.pose.orientation;
// //     tf2::fromMsg(quat_msg, quat_tf);
// //     double roll{}, pitch{}, yaw{};
// //     tf2::Matrix3x3 m(quat_tf);
// //     m.getRPY(roll, pitch, yaw);

// //     float yaw_check = yaw * 180 / M_PI;

// //     if (yaw_check < 0) {
// //       yaw_check = 360.0 - std::abs(yaw_check);
// //     }

// //     robotAngle = yaw_check;

// //     RCLCPP_INFO(this->get_logger(), "position: '%f' '%f'",
// //                 _msg->pose.pose.position.x, _msg->pose.pose.position.y);
// //   }

// //   void timer_callback() {
// //     RCLCPP_INFO(this->get_logger(), "yaw: '%f'", robotAngle);
// //     auto message = geometry_msgs::msg::Twist();
// //     if (robotAngle < 30.0) {
// //       message.angular.z = 0.3;
// //     }

// //     if (robotAngle > 30.0) {
// //       message.angular.z = 0.0;
// //     }

// //     const geometry_msgs::msg::PoseStamped::SharedPtr msg;

// //     publisher_->publish(message);
// //   }

// //   rclcpp::TimerBase::SharedPtr timer_;
// //   rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr subscription_;
// //   rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr publisher_;
// // };

// //------------------------------------------------------------------------------------------------------------

// // Simple tree, used to execute once each action.
// static const char *xml_text = R"(
//  <root >
//      <BehaviorTree>
//      <Sequence>
//       <SetBlackboard   output_key="Interface" value="360" />
//       <SetBlackboard   output_key="Constraint1" value="180" />
//       <SetBlackboard   output_key="Constraint2" value="270" />
//       <SetBlackboard   output_key="Direction1" value="1" />
//       <SetBlackboard   output_key="Direction2" value="2" />
//         <ReactiveSequence> 
         
//            <ReadingLaser input="{Constraint1}"/>
//         </ReactiveSequence> 
//         <MoveRobot input="{Direction1}"/>
//         <ReactiveSequence> 
          
//            <ReadingLaser input="{Constraint2}"/>
//         </ReactiveSequence> 
//         <MoveRobot input="{Direction2}"/>
//     </Sequence>
//      </BehaviorTree>
//  </root>
//  )";

// int main(int argc, char **argv) {
//   rclcpp::init(argc, argv);
//   auto nh = std::make_shared<rclcpp::Node>("sleep_client");

//   BehaviorTreeFactory factory;

//   factory.registerNodeType<MoveRobot>("MoveRobot");
//   factory.registerNodeType<ReadingLaser>("ReadingLaser");
//   // factory.registerNodeType<Rotating>("Rotating");

//   auto tree = factory.createTreeFromText(xml_text);

//   NodeStatus status = NodeStatus::FAILURE;
//   BT::NodeConfiguration con = {};
//   // start laser
//   auto lc_listener = std::make_shared<ReadingLaser>("lc_listener", con);
//   // auto lc_odom = std::make_shared<Rotating>("lc_odom", con);

//   FileLogger logger_file(tree, "bt_trace_project.fbl");
//   while (status == BT::NodeStatus::FAILURE) {
//     // rclcpp::spin_some(lc_odom);
//     rclcpp::spin_some(lc_listener);
//     status = tree.tickRoot();
//     tree.sleep(std::chrono::milliseconds(200));
//   }

//   return 0;
// }



// #include <behaviortree_ros2/bt_action_node.hpp>
// #include <rclcpp/rclcpp.hpp>
// #include "behaviortree_cpp_v3/basic_types.h"
// #include "std_msgs/msg/string.hpp"
// #include <atomic>
// #include <random>
// #include <memory>
// using namespace BT;

// using namespace std::chrono_literals;
// using std::chrono::milliseconds;
// using std::placeholders::_1;

// class SimpleNode : public BT::SyncActionNode, public rclcpp::Node {
// public:
//   SimpleNode(const std::string& name, const BT::NodeConfiguration& config)
//       : BT::SyncActionNode(name, config), Node("bt_node") {
//     RCLCPP_INFO(this->get_logger(), "SimpleNode Constructor");
//   }

//   BT::NodeStatus tick() override {

//     RCLCPP_INFO(this->get_logger(), "SimpleNode tick() called");

//     int value_to_set = generateRandomValue();
//     RCLCPP_INFO(this->get_logger(), "SimpleNode tick() called %d",value_to_set);
//     setOutput("output_value", value_to_set);
//     bool some_condition = true; 

//     if (some_condition) {
//       RCLCPP_INFO(this->get_logger(), "Condition met, returning SUCCESS");
//       return BT::NodeStatus::SUCCESS;  
//     } else {
//       RCLCPP_INFO(this->get_logger(), "Condition not met, returning FAILURE");
//       return BT::NodeStatus::FAILURE;  
//     }
//   }

//   static BT::PortsList providedPorts() {
//     return { OutputPort<int>("output_value") };  // Define output port
//   }

//   private:
//   int generateRandomValue() {
//     // Random number generation using the random library
//     std::random_device rd;  // Obtain a random number from the system
//     std::mt19937 gen(rd()); // Seed the generator
//     std::uniform_int_distribution<> dis(0, 100);  // Define the range (e.g., 0 to 100)
//     return dis(gen);  // Generate a random value within the specified range
//   }
// };


// class ReadNode : public BT::SyncActionNode, public rclcpp::Node {
//   public:
//     ReadNode(const std::string& name, const BT::NodeConfiguration& config)
//         : BT::SyncActionNode(name, config), Node("read_node") {
//       RCLCPP_INFO(this->get_logger(), "ReadNode Constructor");
//     }
  
//     BT::NodeStatus tick() override {
//       RCLCPP_INFO(this->get_logger(), "ReadNode tick() called");
//       return BT::NodeStatus::SUCCESS;
     
//     }
  
//     static BT::PortsList providedPorts() {
//       return { InputPort<int>("output_value")};  // Define input port
//     }
//   };


// int main(int argc, char** argv) {
//   rclcpp::init(argc, argv);
//   rclcpp::executors::SingleThreadedExecutor executor;

//   auto node = std::make_shared<rclcpp::Node>("bt_node_executor");
//   BehaviorTreeFactory factory;
//   factory.registerNodeType<SimpleNode>("SimpleNode");
//   factory.registerNodeType<ReadNode>("ReadNode");
//   BT::Blackboard::Ptr blackboard = BT::Blackboard::create();
//   blackboard->set("output_value", 52);

//   static const char* xml_text = R"(
//   <root>
//     <BehaviorTree>
//       <Sequence>
//         <SimpleNode output_value="{output_value}" />
//         <ReadNode output_value="{output_value}"/>
//       </Sequence>
//     </BehaviorTree>
//   </root>)";

//   auto tree = factory.createTreeFromText(xml_text , blackboard);

//   NodeStatus status = NodeStatus::SUCCESS;
//   while (status == NodeStatus::SUCCESS) {
//     status = tree.tickRoot();
//     tree.sleep(std::chrono::milliseconds(200));  
//   }

//   rclcpp::shutdown();
//   return 0;
// }

#include <behaviortree_ros2/bt_action_node.hpp>
#include <rclcpp/rclcpp.hpp>
#include "behaviortree_cpp_v3/basic_types.h"
#include "std_msgs/msg/string.hpp"
#include <atomic>
#include <random>
#include <memory>
using namespace BT;

using namespace std::chrono_literals;
using std::chrono::milliseconds;
using std::placeholders::_1;

class SimpleNode : public BT::SyncActionNode, public rclcpp::Node {
public:
  SimpleNode(const std::string& name, const BT::NodeConfiguration& config)
      : BT::SyncActionNode(name, config), Node("bt_node") {
    RCLCPP_INFO(this->get_logger(), "SimpleNode Constructor");
  }

  BT::NodeStatus tick() override {
    RCLCPP_INFO(this->get_logger(), "SimpleNode tick() called");

    // Random value generation
    int value_to_set = generateRandomValue();
    RCLCPP_INFO(this->get_logger(), "Generated Value: %d", value_to_set);
    
    // Store the value in the Blackboard
    setOutput("output_value", value_to_set);

    bool some_condition = true;

    if (some_condition) {
      RCLCPP_INFO(this->get_logger(), "Condition met, returning SUCCESS");
      return BT::NodeStatus::SUCCESS;
    } else {
      RCLCPP_INFO(this->get_logger(), "Condition not met, returning FAILURE");
      return BT::NodeStatus::FAILURE;
    }
  }

  static BT::PortsList providedPorts() {
    return { OutputPort<int>("output_value") };  // Define output port
  }

private:
  int generateRandomValue() {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 100);
    return dis(gen);
  }
};

class ReadNode : public BT::SyncActionNode, public rclcpp::Node {
public:
  ReadNode(const std::string& name, const BT::NodeConfiguration& config)
      : BT::SyncActionNode(name, config), Node("read_node") {
    RCLCPP_INFO(this->get_logger(), "ReadNode Constructor");
  }

  BT::NodeStatus tick() override {
    // Read the value from the Blackboard
    int value_from_blackboard;
    if (getInput("output_value", value_from_blackboard)) {
      RCLCPP_INFO(this->get_logger(), "ReadNode tick() - Retrieved Value: %d", value_from_blackboard);
    } else {
      RCLCPP_ERROR(this->get_logger(), "ReadNode tick() - Failed to retrieve value from Blackboard");
    }
    return BT::NodeStatus::SUCCESS;
  }

  static BT::PortsList providedPorts() {
    return { InputPort<int>("output_value") };  // Define input port
  }
};

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  rclcpp::executors::SingleThreadedExecutor executor;

  auto node = std::make_shared<rclcpp::Node>("bt_node_executor");
  BehaviorTreeFactory factory;
  
  // Register the nodes
  factory.registerNodeType<SimpleNode>("SimpleNode");
  factory.registerNodeType<ReadNode>("ReadNode");

  // Create the Blackboard
  BT::Blackboard::Ptr blackboard = BT::Blackboard::create();
  
  // Optionally set initial values on the Blackboard (this value is updated during execution)
  blackboard->set("output_value", 0);  

  // Define BehaviorTree XML
  static const char* xml_text = R"(
  <root>
    <BehaviorTree>
      <Sequence>
        <SimpleNode output_value="{output_value}" />
        <ReadNode output_value="{output_value}"/>
      </Sequence>
    </BehaviorTree>
  </root>)";

  // Create the tree from the XML and provide the Blackboard for shared data access
  auto tree = factory.createTreeFromText(xml_text, blackboard);

  // Execute the tree until completion or a defined exit condition
  NodeStatus status = NodeStatus::SUCCESS;
  while (status == NodeStatus::SUCCESS) {
    status = tree.tickRoot();
    tree.sleep(std::chrono::milliseconds(200));  
  }

  rclcpp::shutdown();
  return 0;
}
