
#include <behaviortree_ros2/bt_action_node.hpp>
#include <rclcpp/rclcpp.hpp>
#include "behaviortree_cpp_v3/basic_types.h"
#include "std_msgs/msg/string.hpp"
#include <atomic>
using namespace BT;

using namespace std::chrono_literals;
using std::chrono::milliseconds;
using std::placeholders::_1;

class SimpleNode : public BT::SyncActionNode, public rclcpp::Node {
public:
  SimpleNode(const std::string& name, const BT::NodeConfiguration& config)
      : BT::SyncActionNode(name, config), Node("simple_node") {
    RCLCPP_INFO(this->get_logger(), "SimpleNode Constructor");
  }

  BT::NodeStatus tick() override {
    RCLCPP_INFO(this->get_logger(), "SimpleNode tick() called!");

    bool some_condition = true; 

    if (some_condition) {
      RCLCPP_INFO(this->get_logger(), "Condition met, returning SUCCESS");
      return BT::NodeStatus::FAILURE;  
    } else {
      RCLCPP_INFO(this->get_logger(), "Condition not met, returning FAILURE");
      return BT::NodeStatus::FAILURE;  
    }
  }

  static BT::PortsList providedPorts() {
    return {}; 
  }
};

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  rclcpp::executors::SingleThreadedExecutor executor;

  auto node = std::make_shared<rclcpp::Node>("simple_node_executor");
  BehaviorTreeFactory factory;
  factory.registerNodeType<SimpleNode>("SimpleNode");

  static const char* xml_text = R"(
  <root>
    <BehaviorTree>
      <Sequence>
        <SimpleNode />
      </Sequence>
    </BehaviorTree>
  </root>)";

  auto tree = factory.createTreeFromText(xml_text);

  NodeStatus status = NodeStatus::FAILURE;
  while (status == NodeStatus::FAILURE) {
    status = tree.tickRoot();
    tree.sleep(std::chrono::milliseconds(200));  // Sleep to simulate periodic execution
  }

  rclcpp::shutdown();
  return 0;
}
