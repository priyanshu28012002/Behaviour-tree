// #include <behaviortree_ros2/bt_action_node.hpp>
// #include <iostream>
// #include <rclcpp/executors.hpp>
// #include <rclcpp/rclcpp.hpp>
// #include "behaviortree_cpp_v3/basic_types.h"
// #include "behaviortree_cpp_v3/tree_node.h"
// #include "std_msgs/msg/string.hpp"
// #include <behaviortree_cpp_v3/loggers/bt_cout_logger.h>

// #include <atomic>
// #include <chrono>
// #include <functional>
// #include <memory>
// #include <string>
// #include <thread>
// #include "geometry_msgs/msg/twist.hpp"
// #include <geometry_msgs/msg/pose_stamped.hpp>
// #include "sensor_msgs/msg/laser_scan.hpp"
// #include "std_msgs/msg/float32.hpp"
// #include "rclcpp/rclcpp.hpp"
// #include "std_msgs/msg/float32.hpp"
// #include <mutex>

// using namespace std::chrono_literals;
// using std::chrono::milliseconds;
// using std::placeholders::_1;
// std::atomic_bool switchActive{true};
// using namespace BT;


// #include <rclcpp/rclcpp.hpp>
// #include <behaviortree_cpp_v3/behavior_tree.h>

// class SimpleNode : public BT::SyncActionNode, public rclcpp::Node {
// public:
//     SimpleNode(const std::string& name, const BT::NodeConfiguration& config)
//         : BT::SyncActionNode(name, config), Node("simple_node") {
//         RCLCPP_INFO(this->get_logger(), "SimpleNode Constructor");
//     }

//     BT::NodeStatus tick() override {
//         int battery_level;
//         if (!config().blackboard->get("node", battery_level)) {
//             battery_level = 100;
//         }

//         RCLCPP_INFO(this->get_logger(), "SimpleNode tick() called! Battery Level: %d", battery_level);
//         bool some_condition = true;

//         if (some_condition) {
//             RCLCPP_INFO(this->get_logger(), "Condition met, returning SUCCESS");
//             return BT::NodeStatus::FAILURE;
//         } else {
//             RCLCPP_INFO(this->get_logger(), "Condition not met, returning FAILURE");
//             return BT::NodeStatus::FAILURE;
//         }
//     }

//     static BT::PortsList providedPorts() {
//         return {};
//     }
// };

// class SetBatteryLevelNode : public BT::SyncActionNode, public rclcpp::Node {
// public:
//     SetBatteryLevelNode(const std::string& name, const BT::NodeConfiguration& config)
//         : BT::SyncActionNode(name, config), Node("set_battery_level_node") {
//         RCLCPP_INFO(this->get_logger(), "SetBatteryLevelNode Constructor");
//         battery_level  = 0;
//     }

//     BT::NodeStatus tick() override {
//       battery_level++;
        
//         config().blackboard->set("node", battery_level);

//         RCLCPP_INFO(this->get_logger(), "SetBatteryLevelNode tick() called! New Battery Level: %d", battery_level);
        
//         return BT::NodeStatus::SUCCESS;
//     }

//     static BT::PortsList providedPorts() {
//         return {};
//     }
//     private:
//     int battery_level;
// };

// class ReadFloat : public BT::AsyncActionNode, public rclcpp::Node {


//   public:
//       ReadFloat(const std::string &name, const BT::NodeConfiguration &config)
//           : BT::AsyncActionNode(name, config), Node("ReadFloat_node") {
          
//           auto sensor_qos = rclcpp::QoS(rclcpp::SensorDataQoS());
//           subscription_ = this->create_subscription<std_msgs::msg::Float32>(
//               "/value", sensor_qos,
//               [&](const std_msgs::msg::Float32::SharedPtr msg) {
//                   topic_callback(msg);
//               });
  
//           publisher_ = this->create_publisher<std_msgs::msg::Float32>("published_value", 10);
  
//           timer_ = this->create_wall_timer(
//               std::chrono::milliseconds(1000), std::bind(&ReadFloat::timer_callback, this));
//       }
  
//       virtual void halt() override {
//           RCLCPP_INFO(this->get_logger(), "HALT IS CALLING ");
//       }
  
//       BT::NodeStatus tick() override {
//           std::lock_guard<std::mutex> lock(data_mutex_);
//           int val =   data1++;
//           config().blackboard->set("node", val);
//           RCLCPP_INFO(this->get_logger(), "Value DATA ===>: %f", data1);
  
//           return data1 > 0.5f ? BT::NodeStatus::SUCCESS : BT::NodeStatus::SUCCESS;
//       }
  
//       static BT::PortsList providedPorts() {
//           return {}; 
//       }
  
  
//       private:
//       rclcpp::Subscription<std_msgs::msg::Float32>::SharedPtr subscription_;
//       rclcpp::TimerBase::SharedPtr timer_;
//       rclcpp::Publisher<std_msgs::msg::Float32>::SharedPtr publisher_;
//       float data1 = 0.0f;
//       std::mutex data_mutex_;  
  
//       void topic_callback(const std_msgs::msg::Float32::SharedPtr _msg) {
//           std::lock_guard<std::mutex> lock(data_mutex_);
//           data1 = _msg->data;  
//           RCLCPP_INFO(this->get_logger(), "I heard: %f", data1);
//       }
  
//       void timer_callback() {
//           auto message = std_msgs::msg::Float32();
//           message.data = data1++;
//           publisher_->publish(message);
//           RCLCPP_INFO(this->get_logger(), "Publishing new data: %f", message.data);
//       }
//   };
  

// static const char *xml_text = R"(
// <root>
//     <BehaviorTree>
//         <Sequence>
//             <SetBatteryLevelNode/>
//             <SimpleNode/>
//         </Sequence>
//     </BehaviorTree>
// </root>
// )";

// int main(int argc, char **argv) {
//     rclcpp::init(argc, argv);
//     auto nh = std::make_shared<rclcpp::Node>("sleep_client");

//     BehaviorTreeFactory factory;
//     factory.registerNodeType<SimpleNode>("SimpleNode");
//     factory.registerNodeType<SetBatteryLevelNode>("SetBatteryLevelNode");
//     factory.registerNodeType<ReadFloat>("ReadFloat");
//     auto blackboard = BT::Blackboard::create();
//     blackboard->set("node", 45);

//     BT::Tree tree = factory.createTreeFromText(xml_text, blackboard);
//     BT::StdCoutLogger logger(tree);    
//     NodeStatus status = NodeStatus::IDLE;
//     BT::NodeConfiguration con = {};
//     auto lc_listener = std::make_shared<ReadFloat>("lc_listener", con);
    

//     while (rclcpp::ok()) {
//       rclcpp::spin_some(lc_listener);
//         status = tree.tickRoot();
//         tree.sleep(std::chrono::milliseconds(100));
//     }

//     rclcpp::shutdown();
//     return 0;
// }


#include <behaviortree_ros2/bt_action_node.hpp>
#include <iostream>
#include <rclcpp/executors.hpp>
#include <rclcpp/rclcpp.hpp>
#include "behaviortree_cpp_v3/basic_types.h"
#include "behaviortree_cpp_v3/tree_node.h"
#include "std_msgs/msg/string.hpp"
#include <behaviortree_cpp_v3/loggers/bt_cout_logger.h>

using namespace std::chrono_literals;
using namespace BT;

class PublishStringNode : public BT::SyncActionNode, public rclcpp::Node {
public:
    PublishStringNode(const std::string& name, const BT::NodeConfiguration& config)
        : BT::SyncActionNode(name, config), Node("publish_string_node") {
        
        publisher_ = this->create_publisher<std_msgs::msg::String>("/string_topic", 10);
        
        RCLCPP_INFO(this->get_logger(), "PublishStringNode Constructor");
    }

    BT::NodeStatus tick() override {
        std_msgs::msg::String message;
        message.data = "Hello from PublishStringNode!";

        publisher_->publish(message);
        RCLCPP_INFO(this->get_logger(), "Published message: %s", message.data.c_str());
        
        return BT::NodeStatus::SUCCESS;
    }

    static BT::PortsList providedPorts() {
        return {};
    }

private:
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
};

class SubscribeStringNode : public BT::SyncActionNode, public rclcpp::Node {
public:
    SubscribeStringNode(const std::string& name, const BT::NodeConfiguration& config)
        : BT::SyncActionNode(name, config), Node("subscribe_string_node") {

        subscription_ = this->create_subscription<std_msgs::msg::String>(
            "/string_topic", 10,
            [&](const std_msgs::msg::String::SharedPtr msg) {
                topic_callback(msg);
            });

        RCLCPP_INFO(this->get_logger(), "SubscribeStringNode Constructor");
    }

    BT::NodeStatus tick() override {
        // Just return SUCCESS since we are waiting for the message asynchronously
        RCLCPP_INFO(this->get_logger(), "Waiting for message from /string_topic");
        return BT::NodeStatus::SUCCESS;
    }

    static BT::PortsList providedPorts() {
        return {};
    }

private:
    void topic_callback(const std_msgs::msg::String::SharedPtr msg) {
        RCLCPP_INFO(this->get_logger(), "Received message: %s", msg->data.c_str());
    }

    rclcpp::Subscription<std_msgs::msg::String>::SharedPtr subscription_;
};

static const char *xml_text = R"(
<root>
    <BehaviorTree>
        <Sequence>
            <PublishStringNode/>
            <SubscribeStringNode/>
        </Sequence>
    </BehaviorTree>
</root>
)";

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    auto nh = std::make_shared<rclcpp::Node>("behavior_tree_client");

    BehaviorTreeFactory factory;
    factory.registerNodeType<PublishStringNode>("PublishStringNode");
    factory.registerNodeType<SubscribeStringNode>("SubscribeStringNode");

    // Create the Blackboard and initialize it
    auto blackboard = BT::Blackboard::create();

    // Create the behavior tree from the XML
    BT::Tree tree = factory.createTreeFromText(xml_text, blackboard);

    // Set up logging
    BT::StdCoutLogger logger(tree);

    // Execute the behavior tree
    BT::NodeStatus status = BT::NodeStatus::IDLE;

    while (rclcpp::ok()) {
        rclcpp::spin_some(nh); // Handle ROS 2 callbacks
        status = tree.tickRoot(); // Tick the behavior tree
        tree.sleep(std::chrono::milliseconds(100)); // Sleep to allow for periodic updates
    }

    rclcpp::shutdown();
    return 0;
}