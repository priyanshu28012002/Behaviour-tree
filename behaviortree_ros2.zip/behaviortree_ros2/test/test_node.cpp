
#include <gtest/gtest.h>

#include <thread>

#include "play_motion2_msgs/srv/is_motion_ready.hpp"
#include "play_motion2_msgs/srv/get_motion_info.hpp"
#include "rclcpp/executors.hpp"
#include "rclcpp/node.hpp"
#include "rclcpp/wait_for_message.hpp"
#include "sensor_msgs/msg/joint_state.hpp"



using namespace std::placeholders;
using namespace std::chrono_literals;
TEST(TuckArmTest, TuckArmTest)
{
  ASSERT_EQ(4,3);
}


int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  testing::InitGoogleTest();
  const auto ret = RUN_ALL_TESTS();
  rclcpp::shutdown();
  return ret;
}
