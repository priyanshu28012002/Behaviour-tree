#ifndef PUB_INT__ADD_HPP_
#define PUB_INT__ADD_HPP_

namespace pub_int {

inline auto add(auto a, auto b) {
  return a + b;
}

}  // namespace pub_int

#endif  // PUB_INT__ADD_HPP_
