#include <memory>
#include <rclcpp/rclcpp.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
#include "behaviortree_ros2/action/my_action.hpp"

using namespace std::chrono_literals;

class FibonacciActionClient : public rclcpp::Node
{
public:
  using MyAction = behaviortree_ros2::action::MyAction;
  using GoalHandleFibonacci = rclcpp_action::ClientGoalHandle<MyAction>;

  explicit FibonacciActionClient(const rclcpp::NodeOptions & options)
  : Node("fibonacci_action_client", options)
  {
    // Create action client
    action_client_ = rclcpp_action::create_client<MyAction>(this, "fibonacci");
  }

  // Send a goal to the action server
  void send_goal(int order)
  {
    if (!action_client_->wait_for_action_server(5s)) {
      RCLCPP_ERROR(this->get_logger(), "Action server not available after waiting");
      return;
    }

    // Create goal
    auto goal_msg = MyAction::Goal();
    goal_msg.order = order;

    // Send goal and handle result and feedback
    auto send_goal_options = rclcpp_action::Client<MyAction>::SendGoalOptions();
    send_goal_options.goal_response_callback =
      std::bind(&FibonacciActionClient::goal_response_callback, this, std::placeholders::_1);
    send_goal_options.feedback_callback =
      std::bind(&FibonacciActionClient::feedback_callback, this, std::placeholders::_1, std::placeholders::_2);
    send_goal_options.result_callback =
      std::bind(&FibonacciActionClient::result_callback, this, std::placeholders::_1);

    action_client_->async_send_goal(goal_msg, send_goal_options);
  }

private:
  // Goal response callback
  void goal_response_callback(std::shared_ptr<GoalHandleFibonacci> goal_handle)
  {
    if (!goal_handle) {
      RCLCPP_ERROR(this->get_logger(), "Goal was rejected by server");
      return;
    }
    RCLCPP_INFO(this->get_logger(), "Goal accepted, waiting for result");
  }

  // Feedback callback
  void feedback_callback(std::shared_ptr<const MyAction::Feedback> feedback)
  {
    RCLCPP_INFO(this->get_logger(), "Received feedback: %s", feedback->feedback.c_str());
  }

  // Result callback
  void result_callback(const rclcpp_action::ClientGoalHandle<MyAction>::WrappedResult & result)
  {
    if (result.code == rclcpp_action::ResultCode::SUCCEEDED) {
      RCLCPP_INFO(this->get_logger(), "Goal succeeded with result: %d", result.result->sum);
    } else {
      RCLCPP_ERROR(this->get_logger(), "Goal failed");
    }
  }

  rclcpp_action::Client<MyAction>::SharedPtr action_client_;
};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  auto client = std::make_shared<FibonacciActionClient>(rclcpp::NodeOptions());
  client->send_goal(10);  // Example goal (Fibonacci sequence order 10)
  rclcpp::spin(client);
  rclcpp::shutdown();
  return 0;
}
