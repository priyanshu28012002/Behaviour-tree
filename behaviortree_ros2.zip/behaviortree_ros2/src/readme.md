In ROS 2 Humble, a node's life cycle is an essential part of managing its state throughout its lifecycle. The lifecycle of a node defines its states and transitions, making it easier to manage resource allocation and deallocation, as well as control the node's execution.

To create a lifecycle node in ROS 2 Humble, you'll need to use the `rclcpp_lifecycle` package. Here's a basic guide on how to create a lifecycle node in ROS 2 Humble.

### Step-by-Step Guide

1. **Create a ROS 2 package** (if you don’t have one already):

```bash
ros2 pkg create --build-type ament_cmake my_lifecycle_node
```

2. **Add dependencies to your `CMakeLists.txt` and `package.xml`**:

In `CMakeLists.txt`, add:

```cmake
find_package(rclcpp REQUIRED)
find_package(rclcpp_lifecycle REQUIRED)
find_package(std_msgs REQUIRED)

# Add your source files here
add_executable(my_lifecycle_node src/my_lifecycle_node.cpp)
ament_target_dependencies(my_lifecycle_node
  rclcpp
  rclcpp_lifecycle
  std_msgs
)

install(TARGETS
  my_lifecycle_node
  DESTINATION lib/${PROJECT_NAME}
)
```

In `package.xml`, add:

```xml
<depend>rclcpp</depend>
<depend>rclcpp_lifecycle</depend>
<depend>std_msgs</depend>
```

3. **Write the lifecycle node code**:

Create a file called `my_lifecycle_node.cpp` in the `src` directory.

```cpp
#include <memory>
#include <rclcpp/rclcpp.hpp>
#include <rclcpp_lifecycle/lifecycle_node.hpp>
#include <std_msgs/msg/string.hpp>

using namespace std::chrono_literals;

class MyLifecycleNode : public rclcpp_lifecycle::LifecycleNode
{
public:
  MyLifecycleNode(const std::string & node_name)
  : rclcpp_lifecycle::LifecycleNode(node_name)
  {
    // You can add initialization logic here
    RCLCPP_INFO(this->get_logger(), "MyLifecycleNode Constructor");
  }

  rclcpp_lifecycle::LifecycleNodeInterface::CallbackReturn on_configure(const rclcpp_lifecycle::State &)
  {
    RCLCPP_INFO(this->get_logger(), "Configuring lifecycle node...");
    publisher_ = this->create_publisher<std_msgs::msg::String>("topic", 10);
    return rclcpp_lifecycle::LifecycleNodeInterface::CallbackReturn::SUCCESS;
  }

  rclcpp_lifecycle::LifecycleNodeInterface::CallbackReturn on_activate(const rclcpp_lifecycle::State &)
  {
    RCLCPP_INFO(this->get_logger(), "Activating lifecycle node...");
    timer_ = this->create_wall_timer(
      1s, std::bind(&MyLifecycleNode::timer_callback, this));
    return rclcpp_lifecycle::LifecycleNodeInterface::CallbackReturn::SUCCESS;
  }

  rclcpp_lifecycle::LifecycleNodeInterface::CallbackReturn on_deactivate(const rclcpp_lifecycle::State &)
  {
    RCLCPP_INFO(this->get_logger(), "Deactivating lifecycle node...");
    timer_ = nullptr;  // Stops the timer
    return rclcpp_lifecycle::LifecycleNodeInterface::CallbackReturn::SUCCESS;
  }

  rclcpp_lifecycle::LifecycleNodeInterface::CallbackReturn on_cleanup(const rclcpp_lifecycle::State &)
  {
    RCLCPP_INFO(this->get_logger(), "Cleaning up lifecycle node...");
    publisher_.reset();
    return rclcpp_lifecycle::LifecycleNodeInterface::CallbackReturn::SUCCESS;
  }

  rclcpp_lifecycle::LifecycleNodeInterface::CallbackReturn on_shutdown(const rclcpp_lifecycle::State &)
  {
    RCLCPP_INFO(this->get_logger(), "Shutting down lifecycle node...");
    return rclcpp_lifecycle::LifecycleNodeInterface::CallbackReturn::SUCCESS;
  }

  rclcpp_lifecycle::LifecycleNodeInterface::CallbackReturn on_error(const rclcpp_lifecycle::State &)
  {
    RCLCPP_ERROR(this->get_logger(), "Lifecycle node encountered an error");
    return rclcpp_lifecycle::LifecycleNodeInterface::CallbackReturn::ERROR;
  }

private:
  void timer_callback()
  {
    auto message = std_msgs::msg::String();
    message.data = "Hello from lifecycle node!";
    publisher_->publish(message);
  }

  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
  rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);

  // Create and spin the lifecycle node
  auto lifecycle_node = std::make_shared<MyLifecycleNode>("my_lifecycle_node");

  rclcpp::spin(lifecycle_node->get_node_base_interface());

  rclcpp::shutdown();
  return 0;
}
```

### Explanation of the Code:

1. **MyLifecycleNode Class**: 
   - Inherits from `rclcpp_lifecycle::LifecycleNode` and implements the lifecycle methods (`on_configure`, `on_activate`, `on_deactivate`, `on_cleanup`, `on_shutdown`, `on_error`).
   - The `on_configure` method initializes the publisher.
   - The `on_activate` method starts a timer to periodically publish messages.
   - The `on_deactivate` method stops the timer when the node is deactivated.
   - The `on_cleanup` method cleans up resources.
   - The `on_shutdown` method handles shutdown logic.
   - The `on_error` method handles error scenarios.

2. **Lifecycle Transitions**: These transitions handle the node's different states:
   - **Unconfigured** → **Configuring** → **Active** → **Deactivating** → **Cleaning up** → **Shutting down**.
   - The node can transition between these states as needed.

3. **Main function**: 
   - Initializes the ROS 2 system with `rclcpp::init()`, creates the lifecycle node, and spins the node.

### 4. **Build the Package**:

After writing the code, go to the root of your workspace and build the package:

```bash
colcon build --packages-select my_lifecycle_node
source install/setup.bash
```

### 5. **Run the Lifecycle Node**:

To run the node, use the following command:

```bash
ros2 run my_lifecycle_node my_lifecycle_node
```

### 6. **Lifecycle Transitions**:

To trigger lifecycle state transitions, you can use `ros2 lifecycle` commands:

- To configure the node:

```bash
ros2 lifecycle set /my_lifecycle_node configure
```

- To activate the node:

```bash
ros2 lifecycle set /my_lifecycle_node activate
```

- To deactivate the node:

```bash
ros2 lifecycle set /my_lifecycle_node deactivate
```

- To clean up the node:

```bash
ros2 lifecycle set /my_lifecycle_node cleanup
```

- To shut down the node:

```bash
ros2 lifecycle set /my_lifecycle_node shutdown
```

This example provides a simple but powerful structure for managing the state of a ROS 2 node, allowing for more robust and flexible operation.